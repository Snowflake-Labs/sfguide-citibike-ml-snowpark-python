#!/usr/bin/env python3
#
# Copyright (c) 2012-2022 Snowflake Computing Inc. All rights reserved.
#

# Update this for the versions
VERSION = (0, 7, 0)
