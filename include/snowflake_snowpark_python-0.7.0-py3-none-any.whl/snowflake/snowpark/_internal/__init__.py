#
# Copyright (c) 2012-2022 Snowflake Computing Inc. All rights reserved.
#
